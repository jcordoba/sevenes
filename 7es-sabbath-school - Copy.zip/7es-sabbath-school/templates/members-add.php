<?php
/**
 * Alta de nuevo miembro - 7es Sabbath School
 * URL: /sevenes-dashboard/members/add/
 */
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! is_user_logged_in() ) {
    wp_safe_redirect( home_url('/sevenes-login/') );
    exit;
}
if ( ! current_user_can('manage_sabbath_members') ) {
    echo '<div class="ss-feedback-error">No tienes permisos para acceder a este módulo.</div>';
    exit;
}

// Breadcrumbs
$breadcrumbs = '<nav class="ss-breadcrumbs"><a href="'.home_url('/sevenes-dashboard/').'">Dashboard</a> <span>&gt;</span> <a href="'.home_url('/sevenes-dashboard/members/').'">Miembros</a> <span>&gt;</span> Nuevo</nav>';
$title = 'Nuevo Miembro | 7es Sabbath School';
$active = 'members';

ob_start();
?>
<div class="ss-members-wrapper">
    <div class="ss-card ss-card-form">
        <h2 class="ss-title">Nuevo Miembro</h2>
        <form id="ss-member-add-form" class="ss-form ss-form-vertical" autocomplete="off" method="post">
            <div class="ss-form-group">
                <label>Nombre(s)*</label>
                <input type="text" name="first_name" required maxlength="100" />
            </div>
            <div class="ss-form-group">
                <label>Apellido(s)*</label>
                <input type="text" name="last_name" required maxlength="100" />
            </div>
            <div class="ss-form-group">
                <label>Identificador*</label>
                <input type="text" name="identification" required maxlength="50" />
            </div>
            <div class="ss-form-group">
                <label>Género*</label>
                <select name="gender" required>
                    <option value="">--</option>
                    <option value="Masculino">Masculino</option>
                    <option value="Femenino">Femenino</option>
                </select>
            </div>
            <div class="ss-form-group">
                <label>Fecha de nacimiento</label>
                <input type="date" name="birthdate" />
            </div>
            <div class="ss-form-group">
                <label>Teléfono</label>
                <input type="text" name="phone" maxlength="30" />
            </div>
            <div class="ss-form-group">
                <label>Celular</label>
                <input type="text" name="mobile" maxlength="30" />
            </div>
            <div class="ss-form-group">
                <label>Email</label>
                <input type="email" name="email" maxlength="100" />
            </div>
            <div class="ss-form-group">
                <label>Rol*</label>
                <select name="role" required>
                    <option value="">--</option>
                    <option value="Alumno">Alumno</option>
                    <option value="Maestro">Maestro</option>
                    <option value="Secretario">Secretario</option>
                    <option value="Director">Director</option>
                </select>
            </div>
            <div class="ss-form-group">
                <label>Clase/Unidad actual</label>
                <input type="text" name="class" maxlength="100" />
            </div>
            <div class="ss-form-group">
                <label><input type="checkbox" name="is_new" value="1" /> ¿Es nuevo converso?</label>
            </div>
            <div class="ss-form-group">
                <label>Año de conversión</label>
                <input type="date" name="baptism_date" />
            </div>
            <div class="ss-form-group">
                <label>Unidad/entrada anterior</label>
                <input type="text" name="unit_entry" maxlength="100" />
            </div>
            <div class="ss-form-group">
                <button type="submit" class="ss-btn ss-btn-primary">Guardar</button>
                <a href="/sevenes-dashboard/members/" class="ss-btn ss-btn-cancel">Cancelar</a>
            </div>
        </form>
        <div id="ss-member-add-feedback" class="ss-feedback"></div>
    </div>
</div>
<?php
$content = ob_get_clean();
$extra_css = '<link rel="stylesheet" href="'.SABBATH_SCHOOL_PLUGIN_URL.'assets/css/members.css">';
include SABBATH_SCHOOL_PLUGIN_PATH.'templates/layout.php';
